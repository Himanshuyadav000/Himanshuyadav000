<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>1_Seated Sofas</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/jpeg" href="images/fav.JPG">
</head>
<body>
    <div class="main">
        <header>
            <h2>J_SOFA..|</h2>
            <nav class="main-nav">
                <a href="home.php" >Home</a>
                <div class="type-menu">
                    <a href="#" class="dropdown-toggle">Type</a>
                    <div class="dropdown">
                        <a href="man.php">MAN</a>
                        <a href="women.php">WOMEN</a>
                    </div>
                </div>
                <a href="#">Contact</a>
                <a href="#">About</a>
            </nav>

            <div class="search">
                <form action="search_results.html" method="GET">
                    <label>
                        <input type="text" placeholder="Search Products" name="query">
                    </label>
                </form>
            </div>

            <nav class="user-nav">
                <div class="profile-menu">
                    <a href="#" class="profile-icon">
                        <span class="icon">&#128100;</span> Profile
                    </a>
                    <div class="dropdown">
                        <a href="../login/login.html">Sign Up</a>
                        <a href="../login/register.html">Registration</a>
                        <a href="#">About User</a>
                        <a href="#">Wishlist</a>
                    </div>
                </div>
                <a href="page1/products1.html" class="cart-icon">
                    <span class="icon">&#128722;</span> Cart
                </a>
            </nav>
        </header>

        <main class="main-content">
            <h1 style="text-align: center; margin-top: 50px;">One Seated Sofa</h1>
            <div class="product-list">
               
                <div class="product-item">
                    <a href="Oproduct1.php" target="_blank">
                        <img src="images/O01.jpg" alt="Sofa 1">
                       <!-- Product Title (Sofa1) -->
                            <h3>Man Watch 1</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.1 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(101 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹2,399</span>
                                <span class="old-price">₹12,000</span>
                                <span class="discount">89% off</span>
                            </div>
                    </a>
                </div>

            

                <div class="product-item">
                    <a href="../page2/Oproduct2.html" target="_blank">
                        <img src="/images/O02.jpg" alt="Sofa 2">
                       <!-- Product Title (Sofa1) -->
                            <h3>A2 J_Sofa  1 Seater Sofa</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(102 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹2,469</span>
                                <span class="old-price">₹13,000</span>
                                <span class="discount">81% off</span>
                            </div>
                    </a>
                </div>

                <div class="product-item">
                    <a href="../page2/Oproduct3.html" target="_blank">
                        <img src="/images/O03.jpg" alt="Sofa 3">
                       <!-- Product Title (Sofa1) -->
                            <h3>A3 J_Sofa  1 Seater Sofa</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.3 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(103 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹3,499</span>
                                <span class="old-price">₹14,000</span>
                                <span class="discount">75% off</span>
                            </div>
                    </a>
                </div>

                <div class="product-item">
                    <a href="../page2/Oproduct4.html" target="_blank">
                        <img src="/images/O04.jpg" alt="Sofa 4">
                       <!-- Product Title (Sofa1) -->
                            <h3>A4 J_Sofa  1 Seater Sofa</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.4 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(104 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹4,199</span>
                                <span class="old-price">₹15,000</span>
                                <span class="discount">72% off</span>
                            </div>
                    </a>
                </div>

                <div class="product-item">
                    <a href="../page2/Oproduct5.html" target="_blank">
                        <img src="/images/O05.jpg" alt="Sofa 5">
                       <!-- Product Title (Sofa1) -->
                            <h3>A5 J_Sofa  1 Seater Sofa</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.5 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(105 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹3,839</span>
                                <span class="old-price">₹16,000</span>
                                <span class="discount">72% off</span>
                            </div>
                    </a>
                </div>

                <div class="product-item">
                    <a href="../page2/Oproduct6.html" target="_blank">
                        <img src="/images/O06.jpg" alt="Sofa 6">
                       <!-- Product Title (Sofa1) -->
                            <h3>A6 J_Sofa  1 Seater Sofa</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.6 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(106 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹3,910</span>
                                <span class="old-price">₹17,000</span>
                                <span class="discount">77% off</span>
                            </div>
                    </a>
                </div>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 J_Sofa. All rights reserved.</p>
        </footer>

        <script src="script.js"></script> <!-- Link to external JavaScript file -->
    </div>
</body>
</html>
