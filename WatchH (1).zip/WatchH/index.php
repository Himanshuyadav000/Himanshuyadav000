<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="High-quality and stylish watch from Shop Ease.">
    <meta name="keywords" content="watchs, Luxury, premium watch, stylish watch, Shop Ease">
    <title>Shop Ease - Home</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/jpeg" href="/images/fav.JPG">
</head>
<bodys>
    <div class="main">
        <header>
            <h2>Shop Ease</h2>
            <nav class="main-nav">
                <a href="home.php" >Home</a>
                <div class="type-menu">
                    <a href="#" class="dropdown-toggle">Category</a>
                    <div class="dropdown">
                        <a href="1man.php">MAN</a>
                        <a href="2women.php">WOMEN</a>
                    </div>
                </div>
                <a href="#">Contact</a>
                <a href="#">About</a>
            </nav>

            <div class="search">
                <form action="Types/search_results.html" method="GET">
                    <label>
                        <input type="text" placeholder="Search Products" name="query">
                    </label>
                </form>
            </div>

            <nav class="user-nav">
                <div class="profile-menu">
                    <a href="#" class="profile-icon">
                        <span class="icon">&#128100;</span> Profile
                    </a>
                    <div class="dropdown">
                        <a href="login.php">Sign Up</a>
                        <a href="register.php">Registration</a>
                        <a href="#">About User</a>
                        <a href="#">Wishlist</a>
                    </div>
                </div>
                <a href="page1/products1.html" class="cart-icon">
                    <span class="icon">&#128722;</span> Cart
                </a>
            </nav>
        </header>

        <!-- Simple Photo Slider -->
        <div class="slider">
            <div class="slides" id="slides">
                <div class="slide">
                    <img src="images/s2.jpg" alt="Watch Image 1">
                    <div class="description">Normal Watch</div>
                </div>
                <div class="slide">
                    <img src="images/s3.jpg" alt="Watch Image 2">
                    <div class="description">Stylish Watch</div>
                </div>
                <div class="slide">
                    <img src="images/s6.jpg" alt="Watch Image 3">
                    <div class="description">Luxury Watch</div>
                </div>
            </div>
        </div>
     
        <!--   main Containt--> 
        <main class="main-content">
            <h1 align="center">Featured Products</h1>
            <div class="product-list">
                
                <div class="product-item">
                    <a href="products1.php" target="_blank">
                        <img src="images/watch2.jpg" alt="Watch 1">
                       <!-- Product Title (Watch1) -->
                            <h3>HORIZEN Stainless Steel Chronograph Luxury Analogue Watch for Men (Blue Dial)</h3>

                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.1 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(110 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹3,000</span>
                                <span class="old-price">₹5,000</span>
                                <span class="discount">10% off</span>
                            </div>
                    </a>
                </div>
            
                <div class="product-item">
                    <a href="products2.php" target="_blank">
                        <img src="images/watch3.jpg" alt="Watch 2">
                       <!-- Product Title (watch1) -->
                            <h3>OLEVS Watch for Men Analog Steel Diamond Waterproof Watch </h3>

                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(120 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹4,000</span>
                                <span class="old-price">₹7,000</span>
                                <span class="discount">15% off</span>
                            </div>
                    </a>
                </div>
            

                <div class="product-item">
                    <a href="products3.php" target="_blank">
                        <img src="images/watch4.jpg" alt="Watch 3">
                       <!-- Product Title (watch1) -->
                            <h3>OLEVS Ladies Watches Rose Gold Quartz Female Watches for Women Waterproof</h3>

                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(120 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹4,000</span>
                                <span class="old-price">₹6,990</span>
                                <span class="discount">10% off</span>
                            </div>
                    </a>
                </div>
            
                <div class="product-item">
                    <a href="products4.php" target="_blank">
                        <img src="images/watch5.jpg" alt="Watch 4">
                       <!-- Product Title (watch1) -->
                            <h3>OLEVS Square Watches for Men Brown Leather Chronograph Fashion Business Watch</h3>

                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(120 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹4,220</span>
                                <span class="old-price">₹5,000</span>
                                <span class="discount">14% off</span>
                            </div>
                    </a>
                </div>
            
                <div class="product-item">
                    <a href="products5.php" target="_blank">
                        <img src="images/watch6.jpg" alt="Watch 5">
                       <!-- Product Title (Watch1) -->
                            <h3>Casio G-Shock GST-B600D-1ADR Bluetooth Analog-Digital Black Dial Men (G1543)</h3>

                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(120 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹21,300</span>
                                <span class="old-price">₹27,990</span>
                                <span class="discount">20% off</span>
                            </div>
                    </a>
                </div>
            
                <div class="product-item">
                    <a href="products6.php" target="_blank">
                        <img src="images/watch7.jpg" alt="Watch 6">
                       <!-- Product Title (Watch1) -->
                            <h3>Matrix Antique 2.0 Day & Date Softest Silicone Strap Analog Watch for Men & Boys</h3>

                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(120 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹2,000</span>
                                <span class="old-price">₹4,000</span>
                                <span class="discount">10% off</span>
                            </div>
                    </a>
                </div>
            
                <div class="product-item">
                    <a href="products7.php" target="_blank">
                        <img src="images/watch10.jpg" alt="watch 7">
                       <!-- Product Title (Watch1) -->
                            <h3>OLEVS Watch for Men Diamond Business Dress Analog Quartz</h3>

                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(120 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹3,400</span>
                                <span class="old-price">₹5,000</span>
                                <span class="discount">60% off</span>
                            </div>
                    </a>
                </div>
            
                <div class="product-item">
                    <a href="products8.php" target="_blank">
                        <img src="images/watch8.jpg" alt="Watch 8">
                       <!-- Product Title (Watch1) -->
                            <h3>Sapphero Watches for Men Waterproof Luminous Watches</h3>

                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(120 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹4,890</span>
                                <span class="old-price">₹6,370</span>
                                <span class="discount">30% off</span>
                            </div>
                    </a>
                </div>
            
                <div class="product-item">
                    <a href="products9.php" target="_blank">
                        <img src="images/watch9.jpg" alt="Watch 9">
                       <!-- Product Title (Watch1) -->
                            <h3>LONGBO Zenith Watch for Men Analog Quartz Dress Diamond Business Stainless Steel Watches </h3>

                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(120 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹2,950</span>
                                <span class="old-price">₹4,930</span>
                                <span class="discount">35% off</span>
                            </div>
                    </a>
                </div>
            </div>
            
        </main>
        <script src="script.js"></script> <!-- Link to external JavaScript file -->
    </div>
    <footer>
        <p>© 2024 Shop Ease. All Rights Reserved.</p>
        <p>
            <a href="#" style="color: black;">Privacy Policy</a> |
            <a href="#" style="color: black;">Terms of Service</a> |
            <a href="#" style="color: black;">Contact Us</a>
        </p>
    </footer>
</body>
</html>
