let currentSlide = 0; // Start with the first slide
const slides = document.getElementById("slides");
const slideItems = document.querySelectorAll(".slide");
const totalSlides = slideItems.length;
const slideDuration = 2000; // hold each slide 5 seconds)
const transitionDuration = 1000; // Duration of the transition 1 second)

function showSlide(index) {
    if (index >= totalSlides) {
        currentSlide = 0; 
    } else if (index < 0) {
        currentSlide = totalSlides - 1; 
    } else {
        currentSlide = index; 
    }

    // Apply fade-out effect to the previous slide
    slideItems.forEach((slide, i) => {
        if (i === currentSlide) {
            slide.style.opacity = 1; 
        } else {
            slide.style.opacity = 0; 
        }
    });

    slides.style.transform = `translateX(-${currentSlide * 100}%)`;
}

function nextSlide() {
    showSlide(currentSlide + 1);
}

// Automatically change slide every 'slideDuration' milliseconds
setInterval(nextSlide, slideDuration + transitionDuration); 


showSlide(currentSlide);

document.querySelector('.search button').addEventListener('click', function(event) {
    event.preventDefault(); // Prevents form submission
    const query = document.querySelector('.search input[type="text"]').value;
    console.log("Search query:", query); // You can replace this with an AJAX call or other actions
});

