<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2_Seated Sofas</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/jpeg" href="/image/fav.JPG">
</head>
<body>
    <div class="main">
        <header>
            <h2>J_SOFA..|</h2>
            <nav class="main-nav">
                <a href="home.php" >Home</a>
                <div class="type-menu">
                    <a href="#" class="dropdown-toggle">Type</a>
                    <div class="dropdown">
                        <a href="1man.php">MAN</a>
                        <a href="2women.php">WOMEN</a>
                    </div>
                </div>
                <a href="#">Contact</a>
                <a href="#">About</a>
            </nav>

            <div class="search">
                <form action="search_results.html" method="GET">
                    <label>
                        <input type="text" placeholder="Search Products" name="query">
                    </label>
                </form>
            </div>

            <nav class="user-nav">
                <div class="profile-menu">
                    <a href="#" class="profile-icon">
                        <span class="icon">&#128100;</span> Profile
                    </a>
                    <div class="dropdown">
                        <a href="login.php">Sign Up</a>
                        <a href="register.php">Registration</a>
                        <a href="#">About User</a>
                        <a href="#">Wishlist</a>
                    </div>
                </div>
                <a href="page1/products1.html" class="cart-icon">
                    <span class="icon">&#128722;</span> Cart
                </a>
            </nav>
        </header>

        <main class="main-content">
            <h1 style="text-align: center; margin-top: 50px;">Two Seated Sofa</h1>
            <div class="product-list">

                <div class="product-item">
                    <a href="w1.php" target="_blank">
                        <img src="images/w1.jpg" alt="w1">
                       <!-- Product Title (Watch) -->
                            <h3>Women Watch1</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.1 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(101 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹16,319</span>
                                <span class="old-price">₹32,000</span>
                                <span class="discount">49% off</span>
                            </div>
                    </a>
                </div>

                 <div class="product-item">
                    <a href="w2.php" target="_blank">
                        <img src="images/w2.jpg" alt="w2">
                       <!-- Product Title (Sofa1) -->
                            <h3>women watch 2</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.2 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(102 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹16,499</span>
                                <span class="old-price">₹33,000</span>
                                <span class="discount">50% off</span>
                            </div>
                    </a>
                </div>

                <div class="product-item">
                    <a href="../page2/Tproduct3.html" target="_blank">
                        <img src="/images/T03.jpg" alt="Sofa 3">
                       <!-- Product Title (Sofa1) -->
                            <h3>J_Sofa T3 Two_Seater Sofa</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.3 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(103 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹16,659</span>
                                <span class="old-price">₹34,000</span>
                                <span class="discount">51% off</span>
                            </div>
                    </a>
                </div>

                <div class="product-item">
                    <a href="../page2/Tproduct4.html" target="_blank">
                        <img src="/images/T04.jpg" alt="Sofa 4">
                       <!-- Product Title (Sofa1) -->
                            <h3>J_Sofa T4 Two_Seater Sofa</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.4 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(104 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹16,799</span>
                                <span class="old-price">₹35,000</span>
                                <span class="discount">52% off</span>
                            </div>
                    </a>
                </div>

                <div class="product-item">
                    <a href="../page2/Tproduct5.html" target="_blank">
                        <img src="/images/T05.jpg" alt="Sofa 5">
                       <!-- Product Title (Sofa1) -->
                            <h3>J_Sofa T5 Two_Seater Sofa</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.5 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(105 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹16,919</span>
                                <span class="old-price">₹36,000</span>
                                <span class="discount">53% off</span>
                            </div>
                    </a>
                </div>

                <div class="product-item">
                    <a href="../page2/Tproduct6.html" target="_blank">
                        <img src="/images/T06.jpg" alt="Sofa 6">
                       <!-- Product Title (Sofa1) -->
                            <h3>J_Sofa T6 Two_Seater Sofa</h3>
                            <!-- Rating Section -->
                            <div class="rating">
                                <div class="rating-box">4.6 ★</div>
                                <div class="stars">★★★★☆</div>
                                <div class="reviews">(106 reviews)</div>
                            </div>

                            <!-- Price Section -->
                            <div class="price-section">
                                <span class="current-price">₹16,999</span>
                                <span class="old-price">₹37,000</span>
                                <span class="discount">54% off</span>
                            </div>
                    </a>
                </div>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 J_Sofa. All rights reserved.</p>
        </footer>

        <script src="script.js"></script> <!-- Link to external JavaScript file -->
    </div>
</body>
</html>
