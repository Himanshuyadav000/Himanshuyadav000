<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>J_Sofa T5 Two_Seater Sofa</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="icon" type="image/jpeg" href="/images/fav.JPG">
</head>
<body>
    <header>
        <h2>J_SOFA..|</h2>
        <nav class="main-nav">
            <a href="../home.html">Home</a>
            <div class="type-menu">
                <a href="#" class="dropdown-toggle">Type</a>
                <div class="dropdown">
                    <a href="Types/1_seated.html">1_Seated</a>
                    <a href="Types/2_Seated.html">2_Seated</a>
                    <a href="Types/4_seated.html">4_Seated</a>
                    <a href="Types/Luxury.html">Luxury</a>

                </div>
            </div>
            <a href="#">Contact</a>
            <a href="#">About</a>
        </nav>

        <div class="search">
            <form action="search_results.html" method="GET">
                <label>
                    <input type="text" placeholder="Search Products" name="query">
                </label>
            </form>
        </div>

        <nav class="user-nav">
            <div class="profile-menu">
                <a href="#" class="profile-icon">
                    <span class="icon">&#128100;</span> Profile
                </a>
                <div class="dropdown">
                    <a href="../login/login.html">Sign Up</a>
                    <a href="../login/register.html">Registration</a>
                    <a href="#">About User</a>
                    <a href="#">Wishlist</a>
                </div>
            </div>
            <a href="page1/products1.html" class="cart-icon">
                <span class="icon">&#128722;</span> Cart
            </a>
        </nav>
    </header>

    <div class="container">
        <!-- Image Section -->
        <div class="image-gallery">
            <div class="main-image">
                <img src="/images/T05.jpg" alt="Sofa Image" id="mainImg">
            </div>
    
            <!-- Add to Cart and Buy Now below the image -->
            <div class="actions">
                <button class="add-to-cart" id="addToCartBtn">ADD TO CART</button>
                <form action="../buy.html" method="get" style="display:inline;">
                    <input type="hidden" name="id" value="1">
                    <button type="submit" class="buy-now">BUY NOW</button>
                </form>
            </div>
        </div>
    
        <!-- Product Details Section -->
        <div class="product-details">
            <h1>J_Sofa T5 Two_Seater Sofa</h1>
            <div class="ratings">
                <span>4.5 ★★★★| 105 Reviews</span>
                <button class="wishlist-btn">&#9825;</button>
            </div>
    
            <!-- Price Section -->
            <div class="price-section">
                <span class="price">₹16,919</span>
                <span class="original-price">₹35,000</span>
                <span class="discount">53% off</span>
            </div>
    
            <!-- Offers Section -->
            <div class="offers">
                <p>Special Price: Extra ₹2105 off</p>
                <p>Available offers...</p>
            </div>
    
            <!-- Delivery Section -->
            <div class="delivery">
                <input type="text" placeholder="Enter Delivery Pincode">
                <button>Check</button>
            </div>
    
            <!-- Capacity Options -->
            <div class="variants">
                <h3>Capacity</h3>
                <div class="capacity-options">
                    <button>2 Seater</button>
                </div>
            </div>
    
            <!-- Highlights -->
            <div class="specifications">
                <h3>Highlights</h3>
                <p>• Upholstery: Imitation Leather</p>
                <p>• Filling Material: Foam</p>
                <p>• W x H x D: 181.61 cm x 71.12 cm x 72.39 cm</p>
                <p>• Symmetrical</p>
                <p>• Delivery Condition: DIY - Basic assembly</p>
            </div>
    
            <!-- Warranty Section -->
            <div class="warranty">
                <h3>Warranty</h3>
                <p>1 Year manufacturer Warranty on the Product</p>
            </div>
    
            <!-- Seller Info -->
            <div class="seller">
                <h3>Seller</h3>
                <p>J_Sofa</p>
                <span class="rating">3.3 ★</span>
                <p>10 Days Return Policy</p>
               <!--<a href="#">See other sellers</a>-->
            </div>
        </div>
    </div>
    
    <script>
        function changeImage(element) {
            document.getElementById('mainImg').src = element.src;
        }
    </script>
    <footer>
        <p>&copy; 2024 SofaStore. All rights reserved.</p>
    </footer>

  </body>
</html>
